#ifdef _LIMITS_H
#define _LIMITS_H

#define MAX_OBJECT_SIZE 1023

#endif
