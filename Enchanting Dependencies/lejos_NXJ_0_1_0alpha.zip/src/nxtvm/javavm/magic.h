
#ifndef _MAGIC_H
#define _MAGIC_H

#define MAGIC 0xCAF6

#endif
