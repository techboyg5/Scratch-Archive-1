package java.lang;

public class IllegalArgumentException extends RuntimeException
{
}
