package java.lang;

public class Exception extends Throwable
{
	public Exception() {
		super();
	}
	
	public Exception(String message) {
		super(message);
	}
}
