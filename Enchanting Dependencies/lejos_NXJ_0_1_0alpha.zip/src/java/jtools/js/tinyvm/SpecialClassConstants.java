package js.tinyvm;
/**
 * Machine-generated file. Do not modify.
 */

public interface SpecialClassConstants {
  static final String[] CLASSES = {
    "java/lang/Object",
    "java/lang/Thread",
    "java/lang/String",
    "java/lang/Throwable",
    "java/lang/Error",
    "java/lang/OutOfMemoryError",
    "java/lang/NoSuchMethodError",
    "java/lang/StackOverflowError",
    "java/lang/NullPointerException",
    "java/lang/ClassCastException",
    "java/lang/ArithmeticException",
    "java/lang/ArrayIndexOutOfBoundsException",
    "java/lang/IllegalArgumentException",
    "java/lang/InterruptedException",
    "java/lang/IllegalStateException",
    "java/lang/IllegalMonitorStateException",
    "java/lang/ThreadDeath"
  };
}
