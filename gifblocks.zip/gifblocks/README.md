![heart](gallery/fourier.gif)

See https://kach.github.io/gifblocks/ for details.
