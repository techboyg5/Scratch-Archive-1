##Based off Scratch from MIT Media lab
scratch.mit.edu

##CSM
This is CSM, a community managed Scratch mod. More information can be found [HERE](http://scratch.mit.edu/discuss/topic/59448/).

##Contributors

- ChocolatePi
- elfin8er
- \_\_init__

