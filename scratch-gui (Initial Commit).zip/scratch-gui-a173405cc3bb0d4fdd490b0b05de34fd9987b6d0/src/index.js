import GUIComponent from './components/gui.jsx';
import BlocksComponent from './components/blocks.jsx';

export const GUI = GUIComponent;
export const Blocks = BlocksComponent;
