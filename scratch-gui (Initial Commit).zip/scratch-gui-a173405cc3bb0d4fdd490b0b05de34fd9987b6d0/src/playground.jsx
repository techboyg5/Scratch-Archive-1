import React from 'react';
import ReactDOM from 'react-dom';
import {GUI} from '.';

ReactDOM.render(
    <GUI />,
    document.getElementById('app'));
