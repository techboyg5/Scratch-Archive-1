package javaPlayer.gui;

public class ContentPane {
	
	public ContentPane() {
		
	}
}
