/**
 * Ver: 0.0
 * Status: Dev
 * License: MIT
 * Developers: GP1 and SJRCS_011
 * Created for Scratch, Mod Share, and Macrobit.
 * Documentation will be available at the official website, as well as some inside the jar itself.
 * An Eclipse workspace will be available to download at sourceforge under the source folder.
 */
//name package
package javaPlayer;
import javaPlayer.gui.ContentPane;
import javax.swing.*;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;


public class JPlayerApplet extends JApplet{
	//initialize class variables
	public double Version = 0.0;
	public JPlayerApplet JPlayerApplet = null;
	public String ModName = null;
	public String ModVer = null;
	public String ProjectLoc = null;
	
	//start initialize script
	public void init(){
		//retrieve params
		System.out.println("Initializing");
		System.out.println("Developed by GP1 and SJRCS_011 for Mod Share, Macrobit, and the Scratch community");
		System.out.println("Developed using Eclipse (eclipse.org).  Code distrubted by SourceForge (sf.net).  Version control system by Git (git-scm.com).");
		System.out.println("Utilizing JRE 6");
		System.out.println("JPlayer Version 0.0");
		try {
		ModName = getParameter("mod");//name of mod
		ModVer = getParameter("modver");//mod ver
		ProjectLoc = getParameter("project");//location of project on host, should be absolute path.
		System.out.println("Paramaters retrieved");
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
		JPlayerApplet = new JPlayerApplet(); //construct the class.  RUN THIS LAST, after initializing everything.
	}
}
