/*
 * 
 */

package javaPlayer.primitives;

public class Sprite extends Morph{
	public Sprite() {
		
	}

}
