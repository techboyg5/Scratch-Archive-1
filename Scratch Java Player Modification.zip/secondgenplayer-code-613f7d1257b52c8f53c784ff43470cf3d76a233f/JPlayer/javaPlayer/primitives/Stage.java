/*
 * 
 */

package javaPlayer.primitives;

public class Stage extends Morph{
	
	public Stage() {
		
	}

}
