
package javaPlayer.primitives;
// This class is the base class of all visible elements on the applet

public class Morph{
	public Morph() {
		
	}
}