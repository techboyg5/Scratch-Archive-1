
package javaPlayer.mods.Gopher;

public class Gopher {
	public Gopher() {
		
	}

}
