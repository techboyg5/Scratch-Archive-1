/*
 * 
 */

package javaPlayer.mods.Ghost;

public class Ghost {
	public Ghost() {
		
	}
}
