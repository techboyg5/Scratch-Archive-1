
package javaPlayer.mods.Streak;

public class Streak {
	public Streak() {
		
	}

}
