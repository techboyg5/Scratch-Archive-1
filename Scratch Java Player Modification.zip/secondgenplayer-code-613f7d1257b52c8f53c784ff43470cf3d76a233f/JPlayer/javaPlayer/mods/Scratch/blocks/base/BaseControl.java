/*
 * This and all other BaseCategory classes are simply libraries of methods for the individual mods to use
 * Thus, they are not executable, so make sure not to call instances of these.
 */
package javaPlayer.mods.Scratch.blocks.base;

public class BaseControl {
	
}
