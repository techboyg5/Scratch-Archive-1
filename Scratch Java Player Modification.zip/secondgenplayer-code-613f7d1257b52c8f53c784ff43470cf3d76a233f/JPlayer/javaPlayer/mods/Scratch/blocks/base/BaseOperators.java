
package javaPlayer.mods.Scratch.blocks.base;
import java.lang.Math;
import java.util.Random;
public class BaseOperators {
	//start Scratch operators
	//start boolean blocks
	//This method is the or boolean in Scratch/Mods
	public boolean or(boolean in1, boolean in2) {
		return in1 || in2;
	}
	//This method is the "not" boolean in Scratch/Mods
	public boolean not(boolean in) {
		return !in;
	}
	//This method is the "and" boolean in Scratch/Mods
	public boolean and(boolean in1, boolean in2) {
		return in1 && in2;
	}
	//This method is the "() = ()" boolean in Scratch/Mods
	public boolean equals(String in1, String in2) {
		return in1 == in2;
	}
	//This method is both the "() < ()" and "() > ()" boolean in Scratch/Mods WIP
	public boolean inequal(String in1, String in2, Character type) {
		return true;
	}
	//end boolean blocks
	//start reporter blocks
	//This method is the "Join ()()" reporter in Scratch/Mods
	public String Join(String str1, String str2) {
		return str1.concat(str2);
	}
	//This method is the "letter () of ()" reporter in Scratch/mods WIP
	public char letterOf(int num, String in) {
		return in.charAt(num);
	}
	//This method is the "length of ()" reporter in Scratch/mods
	public int lengthOf(String in) {
		return in.length();
	}
	//This method is the "()*()" reporter in Scratch/Mods
	public double Times(double num1, double num2) {
		return num1*num2;
	}
	//This method is the "()/()" reporter in Scratch/Mods
	public double Divided(double num1, double num2) {
		return num1/num2;
	}
	//This method is the "()+()" reporter in Scratch/Mods
	public double Added(double num1, double num2) {
		return num1+num2;
	}
	//This method is the "()-()" reporter in Scratch/Mods
	public double Subtracted(double num1, double num2) {
		return num1-num2;
	}
	//This method is the "Pick random () to ()" reporter in Scratch/Mods if the inputs are integers
	public int pickRandomInt(int min, int max) {
		Random random = new Random();
		return min + random.nextInt(max - min);
	}
	//if the input is a double, use this method
	public double pickRandomDouble(double min, double max) {
		Random random = new Random();
		int minInt = (int)(min);
		int maxInt = (int)(max);
		return min + random.nextDouble() + random.nextInt(maxInt - minInt);
	}
	
}
