
package javaPlayer.mods.Scratch.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;
public class Looks extends BaseLooks{

}
