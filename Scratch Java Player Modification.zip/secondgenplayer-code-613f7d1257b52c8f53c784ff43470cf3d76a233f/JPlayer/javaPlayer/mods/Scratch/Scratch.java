
package javaPlayer.mods.Scratch;

public class Scratch {
	public Scratch() {
		
	}

}
