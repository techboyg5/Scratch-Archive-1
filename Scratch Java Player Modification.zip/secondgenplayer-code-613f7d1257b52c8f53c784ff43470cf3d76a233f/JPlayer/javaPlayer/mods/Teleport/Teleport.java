
package javaPlayer.mods.Teleport;

public class Teleport {
	public Teleport() {
		
	}
}
