/*
 * 
 */

package javaPlayer.mods.BYOB.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;
public class Pen extends BasePen{

}
