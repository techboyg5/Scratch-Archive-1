
package javaPlayer.mods.BYOB;

public class BYOB {
	public BYOB() {
		
	}
}
