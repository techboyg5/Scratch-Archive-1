
package javaPlayer.mods.NetScratch;

public class NetScratch {
	public NetScratch() {
		
	}

}
