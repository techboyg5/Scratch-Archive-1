/*
 * 
 */
package javaPlayer.mods.NetScratch.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;

public class Control extends BaseControl{

}
