
package javaPlayer.mods.Kitcat;

public class Kitcat {
	public Kitcat() {
		
	}
}
