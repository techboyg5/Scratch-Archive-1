
package javaPlayer.mods.Kitcat.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;
public class Motion extends BaseMotion{

}
