/*
 * 
 */

package javaPlayer.mods.Infinity;

public class Infinity {
	public Infinity() {
		
	}

}
