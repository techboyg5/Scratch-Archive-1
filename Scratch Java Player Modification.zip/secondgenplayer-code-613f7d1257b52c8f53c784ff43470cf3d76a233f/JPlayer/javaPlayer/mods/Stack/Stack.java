
package javaPlayer.mods.Stack;

public class Stack {
	public Stack() {
		
	}
}
