package javaPlayer.mods.Bingo;

public class Bingo {
	public Bingo() {
		
	}
}
