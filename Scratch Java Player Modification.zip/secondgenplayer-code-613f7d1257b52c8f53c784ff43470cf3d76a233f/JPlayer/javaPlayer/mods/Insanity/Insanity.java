/*
 * 
 */

package javaPlayer.mods.Insanity;

public class Insanity {
	public Insanity() {
		
	}

}
