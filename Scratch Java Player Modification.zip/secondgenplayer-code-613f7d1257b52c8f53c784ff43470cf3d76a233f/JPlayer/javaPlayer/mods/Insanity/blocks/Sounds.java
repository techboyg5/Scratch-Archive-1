/*
 * 
 */

package javaPlayer.mods.Insanity.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;
public class Sounds extends BaseSounds{

}
