/*
 * 
 */

package javaPlayer.mods.Slash;

public class Slash {
	public Slash() {
		
	}
}
