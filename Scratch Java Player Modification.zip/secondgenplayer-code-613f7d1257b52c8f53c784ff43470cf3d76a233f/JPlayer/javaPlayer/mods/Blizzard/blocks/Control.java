package javaPlayer.mods.Blizzard.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;

public class Control extends BaseControl{

}
