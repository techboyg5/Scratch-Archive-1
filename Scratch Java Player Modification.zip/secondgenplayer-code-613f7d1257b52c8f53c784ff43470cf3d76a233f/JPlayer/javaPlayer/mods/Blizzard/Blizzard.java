
package javaPlayer.mods.Blizzard;

public class Blizzard {
	public Blizzard() {
		
	}
}
