package javaPlayer.mods;
//this is the base class all mods extend from
public class Mod {

}
