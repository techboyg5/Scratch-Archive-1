
package javaPlayer.mods.Panther.blocks;
import javaPlayer.mods.Scratch.blocks.base.*;
public class Looks extends BaseLooks{

}
