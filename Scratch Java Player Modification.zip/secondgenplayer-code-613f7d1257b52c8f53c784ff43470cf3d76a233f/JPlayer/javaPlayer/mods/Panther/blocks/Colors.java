
package javaPlayer.mods.Panther.blocks;

public class Colors {

}
