/*
 * 
 */

package javaPlayer.mods.Panther;

public class Panther {
	public Panther() {
		
	}

}
